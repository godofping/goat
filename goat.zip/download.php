<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<a href="APK/ADMIN.apk" download>admin</a>
<br>
<a href="APK/CUSTOMER.apk" download>customer</a>
<br>
<a href="APK/FARMER.apk" download>farmer</a>
<br>

</body>
</html>