<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	
<a href="APK/ADMIN.apk" download>ADMIN</a>
<br>
<a href="APK/CUSTOMER.apk" download>CUSTOMER</a>
<br>
<a href="APK/RAISER.apk" download>RAISER</a>
<br>

</body>
</html>