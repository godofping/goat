<?php 

session_start();
date_default_timezone_set('Asia/Manila');
$connection = mysqli_connect("localhost", "root", "", "goat_db");



 ?>