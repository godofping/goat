<?php include('header.php'); ?>

  <body class="bg-light">
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 pt-5">

          <a href="menu.php"><button type="text" class="btn btn-block btn-warning mb-4">Back</button></a>

          <h5 class="text-center font-weight-bold">Livestock succesfully added!</h5>

           <a href="open-qrcode-scanner.php"><button type="text" class="btn btn-block btn-secondary mt-3 mb-3">Scan again</button></a>
        </div>
       </div>

      <div class="row pt-3">
        <div class="col-md-4"></div>
        <div class="col-md-4">

    

       
      
        </div>
        <div class="col-md-4"></div>

      </div>

        
     
    </div>


    <?php include('footer.php'); ?>