<?php include('header.php'); ?>
  <body class="bg-light">
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 pt-5">
        	<a href="menu.php"><button type="text" class="btn btn-block btn-warning mb-4">Back</button></a>
          <h5 class="text-center font-weight-bold">QR CODE DATA</h5>
        </div>
       </div>

      <div class="row pt-3">
        <div class="col-md-4"></div>
        <div class="col-md-4">

    <?php 

 		$mylocation =  $_GET['mylocation'];

       	$mylocation = explode(",", $mylocation);
  
       	$latitude = $mylocation[0];

       	$longitude = $mylocation[1];

   

        $qrcodeid = explode("qrcodeid=",$_GET['data']);

        $qrcodeid = $qrcodeid[1];

 

        $status = 0;

        if (substr(base64_decode($qrcodeid), 0,10) == "HALALGOATS" ) {
        	$qry = mysqli_query($connection, "select * from livestock_table where liveStockQRId = '" . $qrcodeid  . "'");
          	if (mysqli_num_rows($qry) > 0) {
          		//if qr code is valid and already in used
             	$status = 2;
          	}
          	else
          	{
          		//if qr code is valid and not in used
            	$status = 3;
          	}
       	}

       	else
       	{
       		//code is invalid
        	$status = 1;

       	}

    ?>

    <?php echo $status; ?>

   			

          <?php if ($status == 1): ?>
          	<p class="text-center">You scanned an invalid QR Code. Please use the one provided by the Administrator. Make sure that QR CODE is unused. </p>
          <?php endif ?>

          <?php if ($status == 2): ?>
          	<p class="text-center">You scanned an already registered QR Code. Here are the data.</p>
          	<?php $qry = mysqli_query($connection, "select * from livestock_view where liveStockQRId = '" . $qrcodeid . "'"); $res = mysqli_fetch_assoc($qry); ?>

          	<h4>QR Code ID: </h4>
          	<p><?php echo $res['liveStockQRId']; ?></p>

          	<h4>Weight: </h4>
          	<p><?php echo $res['weight']; ?></p>

          	<h4>Sold Date: </h4>
          	<p><?php echo $res['whenToSold']; ?></p>

          	<h4>Actual Address and GPS: </h4>
          	<p><?php echo $res['actualAddress']; ?> <br> <?php echo $res['gps']; ?></p>

          	<h4>Date added: </h4>
          	<p><?php echo $res['dateAdded']; ?></p>

          	<h4>Farmer name: </h4>
          	<p><?php echo $res['farmerName']; ?></p>

          	<h4>Farmer address:</h4>
          	<p><?php echo $res['farmerAddress']; ?></p>

          <?php endif ?>


          <?php if ($status == 3): ?>
          	<p class="text-center">This QR Code is available for live stock registration.</p>
          	 <a href="add-livestocks.php?mylocation=<?php echo $_GET['mylocation'] ?>&qrcodeid=<?php echo $qrcodeid ?>"><button type="text" class="btn btn-block btn-info mt-3">Register livestock</button></a>
          <?php endif ?>
             

          <a href="open-qrcode-scanner.php"><button type="text" class="btn btn-block btn-secondary mt-3">Scan again</button></a>
 
      
        </div>
        <div class="col-md-4"></div>

      </div>

        
     
    </div>


    <?php include('footer.php'); ?>

 