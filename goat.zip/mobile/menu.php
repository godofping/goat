<?php include('header.php'); ?>
  <body class="bg-light">
  
    <div class="container-fluid">
      <div class="row">
        <div class="col-md-12 pt-5">
          <h5 class="text-center font-weight-bold">MENU</h5>
        </div>
       </div>

      <div class="row pt-3">
        <div class="col-md-4"></div>
        <div class="col-md-4">

   

          <a href="open-qrcode-scanner.php"><button type="text" class="btn btn-block btn-secondary mt-3">Scan Goat QR Code for viewing or registration</button></a>


          <a href="livestocks.php"><button type="text" class="btn btn-block btn-secondary mt-3">Livestocks</button></a>

          <a href="profile.php"><button type="text" class="btn btn-block btn-secondary mt-3">Profile</button></a>
          
          <a href="mobile-controller.php?from=exit"><button type="text" class="btn btn-block btn-secondary mt-3">Exit</button></a>
             
 
      
        </div>
        <div class="col-md-4"></div>

      </div>

        
     
    </div>


    <?php include('footer.php'); ?>

 