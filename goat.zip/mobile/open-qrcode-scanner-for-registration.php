<?php include('header.php'); ?>
  <body class="bg-light">
  
    

        
     
    </div>

    <script type="text/javascript">Android.openScanner();</script>
    <?php include('footer.php'); ?>